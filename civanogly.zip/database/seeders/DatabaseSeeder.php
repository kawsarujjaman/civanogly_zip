<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
         \App\Models\location::factory(10)->create();
         \App\Models\property::factory(50)->create();
         \App\Models\media::factory(500)->create();

    }
}
