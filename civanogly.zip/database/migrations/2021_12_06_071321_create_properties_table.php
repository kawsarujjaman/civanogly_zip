<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePropertiesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('properties', function (Blueprint $table) {
            $table->id();
            $table->string('name');

            $table->string('featured_image');
            $table->unsignedBigInteger('location_id');

            $table->unsignedBigInteger('price');
            $table->unsignedBigInteger('sale')->default(1)->comment('0=rent, 1=sale');
            $table->unsignedBigInteger('type')->default(1)->comment('0=land,1=apertment,2=villa') ;
            $table->unsignedBigInteger('bedrooms')->nullable();
            $table->unsignedBigInteger('bathroms')->nullable();
            $table->unsignedBigInteger('net_sql')->nullable();
            $table->unsignedBigInteger('gross_sql')->nullable();
            $table->unsignedBigInteger('poll')->nullable()->comment('0=no,1=privet,2=public,3=both');

            $table->string('overview');
            $table->longText('whyBuy')->nullable();
            $table->longText('Description')->nullable();
            


            $table->timestamps();

            // $table->foreign('feature_media_id')->references('id')->on('media');

            $table->foreign('location_id')->references('id')->on('locations');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('properties');
    }
}
