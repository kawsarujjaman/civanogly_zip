<div class="fixed top-0 w-full flex py-4 px-12 justify-between item-center z-30 text-white {{request()->routeIs('home') ? '': 'general-header'}} ">
    <div class="min-w-max">
        <a href="{{Route('home')}}">
            <img width="120" src="{!! asset('img/logo.png') !!}" alt="">
        </a>
    </div>

    <div class="w-full">
        <ul class="flex justify-center font-b ">
            <li class="inline-block p-4"> <a href="{{Route('properties')}}?type=0">Land</a> </li>
            <li class="inline-block p-4" > <a href="{{Route('properties')}}?type=2">Villa</a> </li>
            <li class="inline-block p-4" > <a href="{{Route('properties')}}?type=1">Apartment</a> </li>
            <li class="inline-block p-4" > <a href="">About us</a> </li>
            <li class="inline-block p-4" > <a href="">Contact us</a> </li>
        </ul>
    </div>
    <div class="min-w-max text-3xl">
        <a href=""> 🇺🇸  </a>
        <a href=""> 🇧🇩 </a>
    </div>

</div>