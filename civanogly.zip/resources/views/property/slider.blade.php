<div class="largeSlider">
    <div class="single-item" style="background-image: url('https://swiperjs.com/demos/images/nature-1.jpg')"></div>
    <div class="single-item" style="background-image: url('https://swiperjs.com/demos/images/nature-2.jpg')"></div>
    <div class="single-item" style="background-image: url('https://swiperjs.com/demos/images/nature-3.jpg')"></div>
    <div class="single-item" style="background-image: url('https://swiperjs.com/demos/images/nature-4.jpg')"></div>
    <div class="single-item" style="background-image: url('https://swiperjs.com/demos/images/nature-1.jpg')"></div>
    <div class="single-item" style="background-image: url('https://swiperjs.com/demos/images/nature-2.jpg')"></div>
    <div class="single-item" style="background-image: url('https://swiperjs.com/demos/images/nature-3.jpg')"></div>
    <div class="single-item" style="background-image: url('https://swiperjs.com/demos/images/nature-4.jpg')"></div>
</div>
<div class="thumbSlider">
    <div class="single-item" style="background-image: url('https://swiperjs.com/demos/images/nature-1.jpg')"></div>
    <div class="single-item" style="background-image: url('https://swiperjs.com/demos/images/nature-2.jpg')"></div>
    <div class="single-item" style="background-image: url('https://swiperjs.com/demos/images/nature-3.jpg')"></div>
    <div class="single-item" style="background-image: url('https://swiperjs.com/demos/images/nature-4.jpg')"></div>
    <div class="single-item" style="background-image: url('https://swiperjs.com/demos/images/nature-1.jpg')"></div>
    <div class="single-item" style="background-image: url('https://swiperjs.com/demos/images/nature-2.jpg')"></div>
    <div class="single-item" style="background-image: url('https://swiperjs.com/demos/images/nature-3.jpg')"></div>
    <div class="single-item" style="background-image: url('https://swiperjs.com/demos/images/nature-4.jpg')"></div>
</div>