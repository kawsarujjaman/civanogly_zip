<?php

namespace App\Http\Controllers;

use App\Models\property;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function home(){
        $latest_properties = property::latest()->get()->take(4);
       // dd($latest_properties);

        return view('welcome', [
            'latest_properties'=> $latest_properties
    
    ]);

    }
}
